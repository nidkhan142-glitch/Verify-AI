
import React, { useState, useEffect, useRef } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Manifesto } from './components/Manifesto';
import { HowItWorks } from './components/HowItWorks';
import { TeamsSection } from './components/TeamsSection';
import { StatsSection } from './components/StatsSection';
import { AnalysisTool } from './components/AnalysisTool';
import { History } from './components/History';
import { AuthModals } from './components/AuthModals';
import { LimitReachedModal } from './components/LimitReachedModal';
import { supabase } from './supabase';

export enum AuthMode {
  NONE = 'NONE',
  LOGIN = 'LOGIN',
  SIGNUP = 'SIGNUP',
  LIMIT_REACHED = 'LIMIT_REACHED'
}

const App: React.FC = () => {
  const [authMode, setAuthMode] = useState<AuthMode>(AuthMode.NONE);
  const [user, setUser] = useState<any>(null);
  const [credits, setCredits] = useState(0);
  const analysisToolRef = useRef<{ runSample: () => void } | null>(null);
  const [guestCredits, setGuestCredits] = useState(() => {
    const saved = localStorage.getItem('verify_guest_credits');
    return saved !== null ? parseInt(saved, 10) : 30;
  });

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        setUser(session.user);
        fetchCredits(session.user.id);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
      if (session?.user) fetchCredits(session.user.id);
    });

    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    localStorage.setItem('verify_guest_credits', guestCredits.toString());
  }, [guestCredits]);

  const fetchCredits = async (userId: string) => {
    const { data, error } = await supabase
      .from('user_credits')
      .select('credits')
      .eq('user_id', userId)
      .single();
    
    if (data) setCredits(data.credits);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setCredits(0);
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleViewSample = () => {
    scrollToSection('analysis-section');
    setTimeout(() => {
      analysisToolRef.current?.runSample();
    }, 600);
  };

  const handleUpdateGuestCredits = (newCredits: number) => {
    setGuestCredits(newCredits);
  };

  const currentDisplayCredits = user ? credits : guestCredits;

  return (
    <div className="min-h-screen selection:bg-emerald-500/30 bg-[#020617] text-white">
      <Header 
        scrollToSection={scrollToSection}
        setAuthMode={(mode) => setAuthMode(mode as any)} 
        isLoggedIn={!!user}
        userName={user?.user_metadata?.full_name || user?.email?.split('@')[0] || ''}
        credits={currentDisplayCredits}
        onLogout={handleLogout}
      />
      
      <div className="pt-24 space-y-32 pb-32">
        <Hero onAnalyzeClick={() => scrollToSection('analysis-section')} onViewSample={handleViewSample} />
        <div id="how-it-works-section">
          <HowItWorks />
        </div>
        <Manifesto />
        <TeamsSection />
        <StatsSection />
        
        <div id="analysis-section" className="px-6 lg:px-16 max-w-7xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-4">Start Your Analysis</h2>
          <p className="text-slate-400 text-center mb-12 text-sm">Select a content context to begin. This affects analysis tone and recommendations.</p>
          <AnalysisTool 
            ref={analysisToolRef}
            user={user} 
            credits={currentDisplayCredits} 
            onUpdateCredits={() => user ? fetchCredits(user.id) : null}
            guestCredits={guestCredits}
            onUpdateGuestCredits={handleUpdateGuestCredits}
            showLimitModal={() => setAuthMode(AuthMode.LIMIT_REACHED)}
          />
        </div>

        <div id="history-section" className="px-6 lg:px-16 max-w-7xl mx-auto">
          <History />
        </div>

        <section className="px-6 lg:px-16 max-w-7xl mx-auto pt-16 border-t border-slate-900/50">
           <div className="text-center space-y-10">
             <h3 className="text-2xl font-bold tracking-[0.2em] text-slate-400 uppercase">Your Data is Safe With Us</h3>
             <div className="flex flex-wrap justify-center items-center gap-12 md:gap-20">
                <div className="flex items-center gap-3 text-slate-500 hover:text-slate-300 transition-colors">
                  <span className="text-xl">🔒</span>
                  <span className="text-sm font-medium tracking-wide">End-to-End Encryption</span>
                </div>
                <div className="flex items-center gap-3 text-slate-500 hover:text-slate-300 transition-colors">
                  <span className="text-xl">🗑️</span>
                  <span className="text-sm font-medium tracking-wide">Auto-Deletion</span>
                </div>
                <div className="flex items-center gap-3 text-slate-500 hover:text-slate-300 transition-colors">
                  <span className="text-xl">🚫</span>
                  <span className="text-sm font-medium tracking-wide">No Data Sharing</span>
                </div>
                <div className="flex items-center gap-3 text-slate-500 hover:text-slate-300 transition-colors">
                  <span className="text-xl">👁️</span>
                  <span className="text-sm font-medium tracking-wide">Privacy First</span>
                </div>
             </div>
           </div>
        </section>
      </div>

      {/* Auth Modals */}
      {(authMode === AuthMode.LOGIN || authMode === AuthMode.SIGNUP) && (
        <AuthModals 
          mode={authMode as AuthMode.LOGIN | AuthMode.SIGNUP} 
          setMode={(mode) => setAuthMode(mode as any)} 
        />
      )}

      {authMode === AuthMode.LIMIT_REACHED && (
        <LimitReachedModal 
          onContinue={() => setAuthMode(AuthMode.SIGNUP)}
          onClose={() => setAuthMode(AuthMode.NONE)}
        />
      )}

      <div className="fixed inset-0 pointer-events-none -z-20 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <div 
            key={i} 
            className="absolute bg-white rounded-full opacity-20"
            style={{
              width: Math.random() * 2 + 'px',
              height: Math.random() * 2 + 'px',
              top: Math.random() * 100 + '%',
              left: Math.random() * 100 + '%',
            }}
          />
        ))}
      </div>
    </div>
  );
};

export default App;
