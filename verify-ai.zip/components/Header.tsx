
import React from 'react';
import { AuthMode } from '../App';

interface HeaderProps {
  scrollToSection: (id: string) => void;
  setAuthMode: (mode: AuthMode) => void;
  isLoggedIn: boolean;
  userName: string;
  credits: number;
  onLogout: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  scrollToSection,
  setAuthMode, 
  isLoggedIn, 
  userName,
  credits,
  onLogout 
}) => {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#020617]/80 backdrop-blur-xl border-b border-slate-800/50 px-6 lg:px-16 py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div 
          className="text-2xl font-bold tracking-tighter text-white cursor-pointer"
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        >
          Verify AI <span className="text-sm font-normal text-slate-500 ml-1">BETA</span>
        </div>

        <nav className="flex items-center gap-8">
          <button 
            className="text-sm font-medium text-slate-300 hover:text-white transition-colors"
            onClick={() => scrollToSection('how-it-works-section')}
          >
            How it Works
          </button>
          <button 
            className="text-sm font-medium text-slate-300 hover:text-white transition-colors"
            onClick={() => scrollToSection('history-section')}
          >
            History
          </button>
          
          {isLoggedIn ? (
            <div className="flex items-center gap-4 bg-slate-900/50 border border-slate-800 rounded-xl px-4 py-2 ml-4">
               <div className="text-right hidden sm:block">
                  <p className="text-[10px] text-slate-500 mono leading-none mb-1">{userName}</p>
                  <div className="flex items-center gap-2">
                     <button className="text-[11px] font-bold text-slate-300 hover:text-white" onClick={() => scrollToSection('history-section')}>History</button>
                     <span className="text-slate-700">|</span>
                     <button className="text-[11px] font-bold text-slate-300 hover:text-white" onClick={onLogout}>Logout</button>
                  </div>
                  <p className="text-[9px] text-emerald-500 mono mt-1 font-bold">{credits} Credits</p>
               </div>
            </div>
          ) : (
            <div className="flex items-center gap-6 ml-4">
               <div className="text-right hidden sm:block mr-2">
                  <p className="text-[9px] text-emerald-500 mono font-bold uppercase tracking-widest">{credits} Credits Left</p>
               </div>
               <button 
                 onClick={() => setAuthMode(AuthMode.LOGIN)}
                 className="text-sm font-bold text-white hover:text-emerald-400 transition-colors"
               >
                 Login
               </button>
               <button 
                 onClick={() => setAuthMode(AuthMode.SIGNUP)}
                 className="px-6 py-2 bg-[#48ffcc] hover:bg-[#3de0b3] text-[#020617] font-bold rounded-lg transition-all shadow-lg shadow-emerald-500/10"
               >
                 Sign Up
               </button>
            </div>
          )}
        </nav>
      </div>
    </header>
  );
};
