
import React from 'react';

export const Hero: React.FC<{ onAnalyzeClick: () => void; onViewSample: () => void }> = ({ onAnalyzeClick, onViewSample }) => {
  return (
    <section className="relative px-6 lg:px-16 max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-12 py-12 md:py-24 overflow-hidden">
      <div className="flex-1 space-y-10 text-center md:text-left z-10">
        <h1 className="text-6xl lg:text-[5.5rem] font-bold tracking-tight text-white leading-[1] max-w-3xl">
          Authenticity <br />
          <span className="text-[#a5f3e0] opacity-90">Intelligence</span> for <br />
          Modern Contexts
        </h1>
        <p className="text-slate-400 text-xl max-w-xl leading-relaxed font-light">
          Evaluate writing patterns through an ethical, transparent lens. Shift from detection to insight with biological precision.
        </p>
        
        <div className="flex flex-wrap items-center gap-4 justify-center md:justify-start">
          <button 
            onClick={onAnalyzeClick}
            className="px-10 py-3.5 bg-[#48ffcc] hover:bg-[#3de0b3] text-[#020617] font-bold rounded-xl transition-all shadow-xl shadow-emerald-500/10"
          >
            Analyze Now
          </button>
          <button 
            onClick={onViewSample}
            className="px-10 py-3.5 bg-transparent border border-slate-700 text-white font-bold rounded-xl hover:bg-slate-800/50 transition-all"
          >
            View Sample Report
          </button>
        </div>

        <div className="inline-block px-5 py-2.5 bg-emerald-500/5 border border-emerald-500/30 rounded-full">
           <span className="text-[11px] text-[#48ffcc] font-bold uppercase tracking-widest mono">30 Free Credits Available</span>
        </div>
      </div>

      <div className="flex-1 relative flex justify-center items-center min-h-[400px]">
        {/* Restored Ethereal Abstract Visual */}
        <div className="relative w-full max-w-[500px] aspect-square flex items-center justify-center">
           {/* Layered Glows */}
           <div className="absolute inset-0 bg-[#48ffcc]/10 blur-[120px] rounded-full animate-pulse"></div>
           <div className="absolute w-[80%] h-[80%] bg-blue-500/5 blur-[100px] rounded-full animate-pulse" style={{ animationDelay: '1.5s' }}></div>
           
           {/* Central Insight Visual */}
           <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full border border-white/5 backdrop-blur-3xl shadow-[0_0_100px_rgba(72,255,204,0.1)] flex items-center justify-center overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/10 via-transparent to-purple-500/10"></div>
              {/* Dynamic Inner Light */}
              <div className="w-[120%] h-[40%] bg-[#48ffcc]/20 blur-[60px] -rotate-45 animate-pulse"></div>
              {/* Scanning Line Effect */}
              <div className="absolute inset-0 flex flex-col justify-around opacity-20 px-8">
                 {[...Array(6)].map((_, i) => (
                   <div key={i} className="h-px w-full bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,1)]"></div>
                 ))}
              </div>
           </div>

           {/* Orbiting Elements */}
           <div className="absolute w-full h-full border border-slate-800/50 rounded-full animate-[spin_20s_linear_infinite]">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_15px_rgba(16,185,129,1)]"></div>
           </div>
           <div className="absolute w-[80%] h-[80%] border border-slate-800/30 rounded-full animate-[spin_15s_linear_infinite_reverse]">
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-blue-500"></div>
           </div>
        </div>
      </div>
    </section>
  );
};
