
import React, { useState, useImperativeHandle, forwardRef, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { supabase } from '../supabase';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import * as mammoth from 'mammoth';

// PDF.js worker setup
import * as pdfjsLib from 'pdfjs-dist';

// Ensure pdfjs is correctly initialized for browser environment via esm.sh
const PDFJS_VERSION = '3.11.174';
if (pdfjsLib && (pdfjsLib as any).GlobalWorkerOptions) {
  (pdfjsLib as any).GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${PDFJS_VERSION}/pdf.worker.min.js`;
}

interface HeatmapAnnotation {
  start_index: number;
  end_index: number;
  label: "AI_PATTERN" | "HUMAN_PATTERN";
  color: "red" | "blue";
  tooltip_title: string;
  tooltip_explanation: string;
}

interface ForensicReportData {
  score: number;
  confidence: 'Low' | 'Medium' | 'High';
  verdict: 'Likely Human-Written' | 'Likely AI-Generated' | 'AI-Assisted (Hybrid)' | 'Inconclusive (Insufficient Evidence)';
  plain_language_meaning: string;
  key_observations: string[];
  stats: {
    sentence_variance: { result: string; interpretation: string };
    lexical_density: { result: string; interpretation: string };
    burstiness: { result: string; interpretation: string };
    insight: string;
  };
  evidence: {
    ai_patterns: string[];
    human_signals: string[];
    dominance_explanation: string;
  };
  verdict_bullets: string[];
  recommendations: string[];
  heatmap_annotations: HeatmapAnnotation[];
}

interface AnalysisToolProps {
  user: any;
  credits: number;
  onUpdateCredits: () => void;
  guestCredits: number;
  onUpdateGuestCredits: (val: number) => void;
  showLimitModal: () => void;
}

const PHOTOSYNTHESIS_ESSAY = `Photosynthesis is a sophisticated biological process that serves as the primary energy-conversion mechanism for life on Earth. Through the absorption of electromagnetic radiation, specifically within the visible spectrum, photoautotrophs such as plants and cyanobacteria synthesize organic compounds from inorganic precursors. The process occurs within specialized organelles known as chloroplasts, where chlorophyll pigments capture photons to initiate the light-dependent reactions. These reactions facilitate the photolysis of water, releasing molecular oxygen as a byproduct while generating ATP and NADPH. Subsequently, the Calvin Cycle utilizes these energy carriers to fix atmospheric carbon dioxide into triose phosphates, which are eventually converted into glucose and other vital carbohydrates. This intricate cycle not only sustains the growth and development of the organism but also maintains the global atmospheric balance by sequestering carbon and producing the oxygen necessary for aerobic respiration across the biosphere.`;

const STATIC_SAMPLE_REPORT: ForensicReportData = {
  score: 98.5,
  confidence: 'High',
  verdict: 'Likely AI-Generated',
  plain_language_meaning: 'This text exhibits the typical statistical fingerprint of a large language model.',
  key_observations: ['Monotonous rhythm', 'High technical precision', 'Lack of sentence length variance'],
  stats: {
    sentence_variance: { 
      result: 'Low', 
      interpretation: 'Sentences are consistently long and complex (approx. 20-30 words each) with little variation in structure.' 
    },
    lexical_density: { 
      result: 'High', 
      interpretation: 'High concentration of technical terms relative to common words.' 
    },
    burstiness: { 
      result: 'Very Low', 
      interpretation: 'The rhythm is monotonous. A human writer typically varies sentence length to manage reader attention; this text maintains a constant, dense flow.' 
    },
    insight: 'The text lacks the "bursty" nature of human cognitive output.'
  },
  evidence: {
    ai_patterns: ['Uniform sentence structure', 'Perfect grammatical consistency'],
    human_signals: [],
    dominance_explanation: 'Statistical patterns strongly align with model output weights.'
  },
  verdict_bullets: ['Statistical anomaly', 'Syntactic uniformity'],
  recommendations: [
    "If this was intended to be a creative or personal essay, request a rewrite focusing on specific, unique analogies.",
    "Check for 'hallucinations' if the topic were more obscure, though the facts here are standard."
  ],
  heatmap_annotations: [
    {
      start_index: 0,
      end_index: 120,
      label: "AI_PATTERN",
      color: "red",
      tooltip_title: "Syntactic Uniformity",
      tooltip_explanation: "Opening sentence structure is highly typical of LLM introductory patterns."
    },
    {
      start_index: 340,
      end_index: 500,
      label: "AI_PATTERN",
      color: "red",
      tooltip_title: "Optimal Token Path",
      tooltip_explanation: "This sequence follows the statistically most probable token path for common scientific explanations."
    }
  ]
};

export const AnalysisTool = forwardRef(({ 
  user, 
  credits, 
  onUpdateCredits,
  guestCredits,
  onUpdateGuestCredits,
  showLimitModal
}: AnalysisToolProps, ref) => {
  const [activeTab, setActiveTab] = useState<'paste' | 'upload'>('paste');
  const [text, setText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [report, setReport] = useState<ForensicReportData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [rating, setRating] = useState(0);
  const [feedbackText, setFeedbackText] = useState('');
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);
  const [currentAnalysisId, setCurrentAnalysisId] = useState<string | null>(null);
  const reportRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useImperativeHandle(ref, () => ({
    runSample: () => {
      setText(PHOTOSYNTHESIS_ESSAY);
      setReport(STATIC_SAMPLE_REPORT);
      setError(null);
      setFeedbackSubmitted(false);
      setRating(0);
      setFeedbackText('');
      setCurrentAnalysisId(null);
    }
  }));

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setError(null);
    const extension = file.name.split('.').pop()?.toLowerCase();

    try {
      if (extension === 'txt') {
        const content = await file.text();
        setText(content);
      } else if (extension === 'docx') {
        const arrayBuffer = await file.arrayBuffer();
        const result = await (mammoth as any).extractRawText({ arrayBuffer });
        setText(result.value);
      } else if (extension === 'pdf') {
        const arrayBuffer = await file.arrayBuffer();
        const pdf = await (pdfjsLib as any).getDocument({ data: arrayBuffer }).promise;
        let fullText = '';
        for (let i = 1; i <= pdf.numPages; i++) {
          const page = await pdf.getPage(i);
          const content = await page.getTextContent();
          fullText += content.items.map((item: any) => item.str).join(' ') + '\n';
        }
        setText(fullText);
      } else {
        setError('Unsupported file format. Please upload PDF, DOCX, or TXT.');
      }
    } catch (err) {
      console.error(err);
      setError('Failed to extract text from file. Please ensure it is a valid PDF/Word/Text document.');
    }
  };

  const handleAnalyze = async () => {
    if (!user && guestCredits <= 22) {
      showLimitModal();
      return;
    }
    if (credits < 2) {
      setError('Insufficient credits. Each analysis requires 2 credits.');
      return;
    }
    if (!text.trim() || text.length < 50) {
      setError('Please provide at least 50 characters for a valid forensic audit.');
      return;
    }
    
    setIsAnalyzing(true);
    setReport(null);
    setError(null);
    setFeedbackSubmitted(false);
    setRating(0);
    setFeedbackText('');

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `Perform a full forensic authorship analysis on this text. 
        
        TEXT TO ANALYZE:
        "${text}"`,
        config: {
          systemInstruction: `You are Verify AI’s Forensic Report Composer. Output JSON only. Logic-based authorship verification. 2 credits will be consumed.
          Return a JSON object with this exact structure:
          {
            "score": number,
            "confidence": "Low" | "Medium" | "High",
            "verdict": "Likely Human-Written" | "Likely AI-Generated" | "AI-Assisted (Hybrid)" | "Inconclusive (Insufficient Evidence)",
            "plain_language_meaning": "string",
            "key_observations": ["string"],
            "stats": {
              "sentence_variance": { "result": "string", "interpretation": "string" },
              "lexical_density": { "result": "string", "interpretation": "string" },
              "burstiness": { "result": "string", "interpretation": "string" },
              "insight": "string"
            },
            "evidence": {
              "ai_patterns": ["string"],
              "human_signals": ["string"],
              "dominance_explanation": "string"
            },
            "verdict_bullets": ["string"],
            "recommendations": ["string"],
            "heatmap_annotations": [
              {
                "start_index": number,
                "end_index": number,
                "label": "AI_PATTERN" | "HUMAN_PATTERN",
                "color": "red" | "blue",
                "tooltip_title": "string",
                "tooltip_explanation": "string"
              }
            ]
          }`,
          responseMimeType: "application/json",
        }
      });

      const data = JSON.parse(response.text || '{}') as ForensicReportData;
      setReport(data);

      if (user) {
        const { data: analysisData, error: saveError } = await supabase
          .from('analyses')
          .insert({
            user_id: user.id,
            input_text: text,
            report_data: data,
            score: data.score,
            verdict: data.verdict
          })
          .select()
          .single();

        if (saveError) throw saveError;
        setCurrentAnalysisId(analysisData.id);

        await supabase
          .from('user_credits')
          .update({ credits: credits - 2 })
          .eq('user_id', user.id);

        onUpdateCredits();
      } else {
        onUpdateGuestCredits(guestCredits - 2);
      }

      const history = JSON.parse(localStorage.getItem('verify_history') || '[]');
      history.unshift({ date: new Date().toISOString(), score: data.score, verdict: data.verdict, preview: text.slice(0, 100) });
      localStorage.setItem('verify_history', JSON.stringify(history.slice(0, 10)));

    } catch (err: any) {
      console.error("Forensic Error:", err);
      setError('Analysis failed. ' + (err.message || 'Check your connection.'));
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleFeedback = async () => {
    if (!user || !currentAnalysisId) return;
    const { error } = await supabase
      .from('feedback')
      .insert({ user_id: user.id, analysis_id: currentAnalysisId, rating, comment: feedbackText });
    if (!error) setFeedbackSubmitted(true);
  };

  const downloadPDF = async () => {
    if (!reportRef.current) return;
    try {
      const canvas = await html2canvas(reportRef.current, { 
        scale: 2, 
        backgroundColor: '#020617',
        useCORS: true,
        logging: false
      });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`VerifyAI_Forensic_Report_${new Date().getTime()}.pdf`);
    } catch (err) {
      console.error('PDF Export Failed:', err);
      alert('Failed to generate PDF. Please try again.');
    }
  };

  const shareAnalysis = async () => {
    if (!report || !currentAnalysisId) {
      alert("Sharing is only available for actual analyses, not samples.");
      return;
    }
    const { data } = await supabase.from('public_reports').insert({ analysis_id: currentAnalysisId, data: report }).select().single();
    if (data) {
      const shareUrl = `${window.location.origin}/report/${data.id}`;
      navigator.clipboard.writeText(shareUrl);
      alert('Public link copied to clipboard!');
    }
  };

  const renderHeatmap = () => {
    if (!report || !text) return null;
    const annotations = Array.isArray(report.heatmap_annotations) ? report.heatmap_annotations : [];
    const elements: React.ReactNode[] = [];
    let lastIndex = 0;
    const sortedAnnotations = [...annotations].sort((a, b) => a.start_index - b.start_index);
    sortedAnnotations.forEach((anno, idx) => {
      if (anno.start_index > lastIndex) elements.push(<span key={`text-${idx}`}>{text.substring(lastIndex, anno.start_index)}</span>);
      const highlightText = text.substring(anno.start_index, anno.end_index);
      const colorClass = anno.color === 'red' ? 'bg-red-500/20 border-b-2 border-red-500/60' : 'bg-blue-500/20 border-b-2 border-blue-500/60';
      const labelColor = anno.color === 'red' ? 'text-red-400' : 'text-blue-400';
      elements.push(
        <span key={`anno-${idx}`} className={`relative group cursor-help transition-all px-0.5 rounded-sm ${colorClass}`}>
          {highlightText}
          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 hidden group-hover:block z-50 w-64 p-3 bg-slate-900 border border-slate-700 rounded-lg shadow-2xl pointer-events-none animate-in fade-in zoom-in-95 duration-200">
             <p className={`text-[10px] font-black mb-1 mono uppercase tracking-widest ${labelColor}`}>{anno.tooltip_title}</p>
             <p className="text-[11px] text-slate-300 leading-normal">{anno.tooltip_explanation}</p>
             <div className="absolute top-full left-1/2 -translate-x-1/2 border-8 border-transparent border-t-slate-900"></div>
          </div>
        </span>
      );
      lastIndex = anno.end_index;
    });
    if (lastIndex < text.length) elements.push(<span key="text-last">{text.substring(lastIndex)}</span>);
    return elements;
  };

  const resetAnalysis = () => {
    setReport(null);
    setText('');
    setError(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="space-y-12 max-w-5xl mx-auto">
      {!report && (
        <>
          <div className="bg-[#020617]/40 border border-slate-800 rounded-3xl overflow-hidden backdrop-blur-sm relative group">
            <div className="flex border-b border-slate-800">
              <button onClick={() => setActiveTab('paste')} className={`flex-1 py-4 flex items-center justify-center gap-2 font-bold text-sm transition-all ${activeTab === 'paste' ? 'bg-slate-800/50 text-emerald-400 border-b-2 border-emerald-500' : 'text-slate-500 hover:text-slate-300'}`}>📋 Paste Text</button>
              <button onClick={() => setActiveTab('upload')} className={`flex-1 py-4 flex items-center justify-center gap-2 font-bold text-sm transition-all ${activeTab === 'upload' ? 'bg-slate-800/50 text-emerald-400 border-b-2 border-emerald-500' : 'text-slate-500 hover:text-slate-300'}`}>📁 Upload File</button>
            </div>
            <div className="p-10">
              {activeTab === 'paste' ? (
                <textarea 
                  value={text} 
                  onChange={(e) => setText(e.target.value)} 
                  placeholder="Paste content for forensic audit (2 credits required)..." 
                  className="w-full h-80 bg-transparent text-slate-200 placeholder:text-slate-800 focus:outline-none resize-none mono text-sm leading-relaxed" 
                />
              ) : (
                <div className="w-full h-80 flex flex-col items-center justify-center border-2 border-dashed border-slate-800 rounded-2xl bg-slate-900/20 group-hover:border-emerald-500/30 transition-all">
                  <input 
                    type="file" 
                    ref={fileInputRef} 
                    onChange={handleFileUpload} 
                    className="hidden" 
                    accept=".pdf,.docx,.txt"
                  />
                  <div className="text-center space-y-4">
                    <div className="text-5xl">📄</div>
                    <div className="space-y-1">
                      <p className="text-white font-bold">Upload your document</p>
                      <p className="text-slate-500 text-xs mono uppercase">PDF, DOCX, TXT (Max 5MB)</p>
                    </div>
                    <button 
                      onClick={() => fileInputRef.current?.click()}
                      className="px-6 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold rounded-lg border border-slate-700"
                    >
                      Select File
                    </button>
                    {text && (
                      <div className="mt-4 p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
                        <p className="text-emerald-400 text-xs mono">✓ Text successfully extracted ({text.length} characters)</p>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="flex flex-col items-center gap-4">
            <button 
              onClick={() => handleAnalyze()} 
              disabled={isAnalyzing || !text.trim()} 
              className={`px-16 py-4 rounded-2xl font-black text-lg transition-all shadow-2xl flex items-center gap-4 ${isAnalyzing || !text.trim() ? 'bg-slate-800 text-slate-600 cursor-not-allowed' : 'bg-emerald-500 hover:bg-emerald-400 text-[#020617]'}`}
            >
              {isAnalyzing ? 'Processing...' : 'Run Insight Analysis'}
            </button>
            <p className="text-[10px] text-slate-500 mono uppercase tracking-widest">Cost: 2 Credits per analysis</p>
          </div>
          {error && <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm text-center font-bold">⚠️ {error}</div>}
        </>
      )}

      {isAnalyzing && (
        <div className="fixed inset-0 z-[100] bg-[#020617]/95 backdrop-blur-xl flex flex-col items-center justify-center space-y-8 animate-in fade-in duration-300">
           <div className="relative w-24 h-24">
              <div className="absolute inset-0 rounded-full border-4 border-emerald-500/20 border-t-emerald-500 animate-spin"></div>
              <div className="absolute inset-4 rounded-full border-4 border-blue-500/20 border-b-blue-500 animate-spin" style={{ animationDirection: 'reverse' }}></div>
           </div>
           <div className="text-center space-y-2">
              <h3 className="text-2xl font-black text-white tracking-tighter">Analyzing text using Verify AI</h3>
              <p className="text-slate-500 mono text-xs uppercase tracking-[0.3em] animate-pulse">PLEASE WAIT . . .</p>
           </div>
           <div className="max-w-xs w-full bg-slate-900 h-1 rounded-full overflow-hidden">
              <div className="bg-emerald-500 h-full w-full animate-progress-indefinite"></div>
           </div>
        </div>
      )}

      {report && (
        <div id="report-view" ref={reportRef} className="animate-in slide-in-from-bottom-12 duration-1000 space-y-12 pb-24">
          <div className="text-center space-y-2">
            <h2 className="text-3xl font-black text-white tracking-tighter uppercase">🔍 Verify AI — Authorship Verification Report</h2>
            <div className="w-32 h-1.5 bg-emerald-500 mx-auto rounded-full"></div>
          </div>

          <div className="p-1 rounded-[3rem] bg-gradient-to-br from-slate-700/30 to-black border border-slate-800/50 shadow-2xl overflow-hidden">
            <div className="bg-[#020617]/90 backdrop-blur-2xl p-8 md:p-16 space-y-20">
              <section className="flex flex-col md:flex-row items-center justify-between gap-12 border-b border-slate-900 pb-16">
                <div className="space-y-4 text-center md:text-left">
                  <h3 className="text-xs font-black text-slate-500 uppercase tracking-[0.2em] mono">🎯 AI Likelihood Score</h3>
                  <div className="flex flex-col gap-2">
                    <span className={`text-7xl font-black tracking-tighter ${report.score > 50 ? 'text-red-500' : 'text-emerald-500'}`}>
                      {report.score} / 100
                    </span>
                    <div className="flex items-center gap-4 justify-center md:justify-start text-sm font-bold mono uppercase">
                       <span className="text-slate-400">Verdict: {report.verdict}</span>
                    </div>
                  </div>
                </div>
                <div className="max-w-md bg-slate-900/30 p-8 rounded-3xl border border-slate-800/50 text-xs text-slate-400 italic">
                  This score represents the probability that the text was generated primarily by an AI system.
                </div>
              </section>

              <section className="space-y-8">
                <h3 className="text-xs font-black text-slate-500 uppercase tracking-widest mono">🎨 Pattern Heatmap</h3>
                <div className="p-12 rounded-[2.5rem] bg-slate-900/40 border border-slate-800 text-slate-200 leading-[2.4] text-base md:text-lg font-medium shadow-inner">
                  {renderHeatmap()}
                </div>
              </section>

              <section className="space-y-8">
                <h3 className="text-xs font-black text-slate-500 uppercase tracking-widest mono">📊 Statistical Signals</h3>
                <div className="overflow-hidden border border-slate-800 rounded-3xl bg-slate-950/50">
                   <table className="w-full text-left">
                     <thead className="bg-slate-900 border-b border-slate-800 text-[10px] text-slate-500 mono uppercase">
                        <tr><th className="p-6">Signal</th><th className="p-6">Result</th><th className="p-6">Interpretation</th></tr>
                     </thead>
                     <tbody className="text-sm divide-y divide-slate-800">
                        <tr><td className="p-6 font-bold">Sentence Variance</td><td className="p-6">{report.stats?.sentence_variance?.result || 'N/A'}</td><td className="p-6 text-slate-400">{report.stats?.sentence_variance?.interpretation || 'N/A'}</td></tr>
                        <tr><td className="p-6 font-bold">Burstiness</td><td className="p-6">{report.stats?.burstiness?.result || 'N/A'}</td><td className="p-6 text-slate-400">{report.stats?.burstiness?.interpretation || 'N/A'}</td></tr>
                     </tbody>
                   </table>
                </div>
              </section>

              <section className="bg-emerald-500/5 border border-emerald-500/20 p-12 rounded-[2.5rem]">
                <h4 className="text-[10px] font-black text-emerald-500 uppercase tracking-widest mono mb-6">🛠️ Recommendations</h4>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {(report.recommendations || []).map((r, i) => (
                    <li key={i} className="text-sm text-slate-200 flex items-start gap-4">• {r}</li>
                  ))}
                </ul>
              </section>

              <section className="pt-20 border-t border-slate-900/50 text-center space-y-10">
                 {!feedbackSubmitted ? (
                    <>
                      <div className="space-y-2">
                        <h3 className="text-3xl font-black text-[#48ffcc]">Help us improve</h3>
                        <p className="text-slate-400">How accurate was this report?</p>
                      </div>
                      <div className="flex justify-center gap-4">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button key={star} onClick={() => setRating(star)} className={`text-4xl transition-all hover:scale-125 ${rating >= star ? 'text-yellow-400' : 'text-slate-700'}`}>★</button>
                        ))}
                      </div>
                      <div className="max-w-xl mx-auto">
                        <textarea value={feedbackText} onChange={(e) => setFeedbackText(e.target.value)} placeholder="What would you improve?" className="w-full bg-slate-900/50 border border-slate-800 rounded-xl p-6 text-slate-300 focus:outline-none focus:border-emerald-500/50 min-h-[120px]" />
                      </div>
                      <button onClick={handleFeedback} className="px-10 py-3 bg-slate-900 border border-slate-800 text-white font-bold rounded-xl hover:bg-slate-800 transition-colors">Submit Feedback</button>
                    </>
                 ) : (
                    <div className="py-10 text-emerald-400 font-bold">Thank you for your feedback!</div>
                 )}
              </section>

              <section className="pt-16 flex flex-col items-center gap-12">
                 <button onClick={resetAnalysis} className="px-16 py-5 bg-emerald-500 hover:bg-emerald-400 text-[#020617] font-black text-xl rounded-2xl transition-all">Continue Analyzing</button>
                 <div className="flex gap-4">
                    <button onClick={shareAnalysis} className="px-8 py-3 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl border border-slate-800">SHARE ANALYSIS</button>
                    <button onClick={downloadPDF} className="px-8 py-3 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl border border-slate-800">DOWNLOAD PDF</button>
                 </div>
              </section>
            </div>
          </div>
        </div>
      )}
      <style>{`
        @keyframes progress-indefinite { 0% { transform: translateX(-100%); } 100% { transform: translateX(100%); } }
        .animate-progress-indefinite { animation: progress-indefinite 2s linear infinite; }
      `}</style>
    </div>
  );
});
