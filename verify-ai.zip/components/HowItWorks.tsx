
import React from 'react';

export const HowItWorks: React.FC = () => {
  const steps = [
    { title: "Choose Your Context", desc: "Select HR, Legal, or Academic", icon: "✏️" },
    { title: "Upload or Paste Text", desc: "Process logs or static files", icon: "📄" },
    { title: "AI Analyzes Patterns", desc: "80/20 forensic triangulation", icon: "🔍" },
    { title: "Review Insights & Recommendations", desc: "Download full forensic report", icon: "📊" }
  ];

  return (
    <section id="how-it-works" className="px-6 lg:px-16 max-w-7xl mx-auto space-y-16">
      <div className="text-center space-y-4">
        <h2 className="text-5xl font-bold text-white tracking-tighter">How It Works</h2>
        <p className="text-slate-400">Simple, transparent, and powerful AI content analysis</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {steps.map((step, idx) => (
          <div key={idx} className="group p-8 rounded-2xl bg-slate-900/40 border border-slate-800 hover:border-emerald-500/30 transition-all flex flex-col items-center text-center space-y-6">
            <div className="w-16 h-16 rounded-xl bg-slate-800 flex items-center justify-center text-3xl group-hover:scale-110 transition-transform">
              {step.icon}
            </div>
            <div className="space-y-2">
              <span className="text-emerald-400 text-[10px] font-bold uppercase tracking-widest mono">Step {idx + 1}</span>
              <h3 className="text-white font-bold text-xl">{step.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">{step.desc}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
